package amalia.skripsi.deteksipadi.data

import kotlinx.serialization.Serializable

@Serializable
data class UserProfile(
    val id: String,
    val email: String? = null,
    val full_name: String? = null,
    val avatar_url: String? = null,
    val role: String? = null,
    val nip: String? = null,
    val phone_number: String? = null,
    val alamat: String? = null,
    val is_active: Boolean = true,
    val created_at: String? = null,
    val fcm_token: String? = null,
    val push_notifications_enabled: Boolean = true,
    val poktan_id: String? = null,
    val master_poktan: MasterPoktanDto? = null, // Relasi Ditarik
    val wkpp_kecamatan: List<String>? = null
)

@Serializable
data class ProfileDto(
    val id: String,
    val email: String? = null,
    val full_name: String? = null,
    val avatar_url: String? = null,
    val role: String? = null,
    val nip: String? = null,
    val phone_number: String? = null,
    val alamat: String? = null,
    val is_active: Boolean = true,
    val created_at: String? = null,
    val fcm_token: String? = null,
    val push_notifications_enabled: Boolean = true,
    val poktan_id: String? = null,
    val master_poktan: MasterPoktanDto? = null
)

@Serializable
data class PoptProfile(
    val full_name: String? = null,
    val wkpp_kecamatan: List<String>? = null
)

@Serializable
data class PoptWilayahDto(
    val kecamatan_id: String,
    val kecamatan: KecamatanSimpleDto? = null
)

@Serializable
data class NotificationPreferenceDto(
    val push_notifications_enabled: Boolean = true
)