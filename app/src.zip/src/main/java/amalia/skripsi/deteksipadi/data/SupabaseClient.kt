@file:Suppress("DEPRECATION")
package amalia.skripsi.deteksipadi.data

import amalia.skripsi.deteksipadi.ml.DetectionResult
import android.util.Log
import com.google.android.gms.maps.model.LatLng
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Columns
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.postgrest.rpc
import io.github.jan.supabase.realtime.Realtime
import io.github.jan.supabase.storage.Storage
import io.github.jan.supabase.storage.storage
import io.ktor.client.engine.okhttp.OkHttp
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.double
import kotlinx.serialization.json.contentOrNull

val supabase = createSupabaseClient(
    supabaseUrl = "https://rhlixmoadeexgvrbxkmo.supabase.co",
    supabaseKey = "sb_publishable_dV8oRP92tnXhqDantHWkkg_RTgO3V4P"
) {
    httpEngine = OkHttp.create()
    install(Postgrest)
    install(Storage)
    install(Auth)
    install(Realtime)
}

const val LAPORAN_COLUMNS = "id, petani_id, foto_url, label_ai, confidence, status, prioritas, termasuk_cluster, lat, lon, alamat_lengkap, created_at, deskripsi_gejala, instruksi_popt, radius, jenis_pelaporan, kecamatan_id, alasan_penolakan, alasan_kunjungan"

const val LAPORAN_MAP_COLUMNS = "id, petani_id, foto_url, label_ai, confidence, status, prioritas, termasuk_cluster, created_at, deskripsi_gejala, instruksi_popt, kecamatan_id, alasan_penolakan, alasan_kunjungan, radius, jenis_pelaporan, lat, lon"

@Serializable
data class LaporanDto(
    val id: String,
    val petani_id: String,
    val foto_url: String = "",
    val label_ai: String? = null,
    val confidence: Float? = null,
    val status: String = "menunggu_verifikasi",
    val prioritas: String? = null,
    val termasuk_cluster: Boolean = false,
    val alamat_lengkap: String? = null,
    val created_at: String = "",

    @SerialName("lokasi")
    val lokasi: JsonElement? = null,

    val deskripsi_gejala: String = "",
    val instruksi_popt: String? = null,
    val radius: Double = 0.3,
    val jenis_pelaporan: String = "ai",
    val kecamatan_id: String? = null,
    val alasan_penolakan: String? = null,
    val alasan_kunjungan: String? = null,

    @SerialName("lat")
    private val latitudeFromMap: Double? = null,

    @SerialName("lon")
    private val longitudeFromMap: Double? = null
) {
    val lat: Double
        get() = latitudeFromMap
            ?: parsePointLocation(lokasi)?.first
            ?: 0.0

    val lon: Double
        get() = longitudeFromMap
            ?: parsePointLocation(lokasi)?.second
            ?: 0.0
}

@Serializable
data class LaporanPetaDto(
    val id: String,
    val petani_id: String,
    val foto_url: String = "",
    val label_ai: String? = null,
    val confidence: Float? = null,
    val status: String = "menunggu_verifikasi",
    val prioritas: String? = null,
    val termasuk_cluster: Boolean = false,
    val created_at: String = "",
    val deskripsi_gejala: String = "",
    val instruksi_popt: String? = null,
    val kecamatan_id: String? = null,
    val alasan_penolakan: String? = null,
    val alasan_kunjungan: String? = null,
    val radius: Double = 0.3,
    val jenis_pelaporan: String = "ai",
    val lat: Double,
    val lon: Double
)

private fun parsePointLocation(value: JsonElement?): Pair<Double, Double>? {
    if (value == null) return null
    return try {
        when (value) {
            is kotlinx.serialization.json.JsonObject -> {
                val coords = value["coordinates"]?.jsonArray ?: return null
                if (coords.size >= 2) coords[1].jsonPrimitive.double to coords[0].jsonPrimitive.double else null
            }
            is kotlinx.serialization.json.JsonPrimitive -> {
                val raw = value.contentOrNull ?: return null
                val match = Regex("POINT\\s*\\(\\s*(-?\\d+(?:\\.\\d+)?)\\s+(-?\\d+(?:\\.\\d+)?)\\s*\\)", RegexOption.IGNORE_CASE).find(raw)
                    ?: Regex("(-?\\d+(?:\\.\\d+)?)\\s*,\\s*(-?\\d+(?:\\.\\d+)?)").find(raw)
                if (match != null) match.groupValues[2].toDouble() to match.groupValues[1].toDouble() else null
            }
            else -> null
        }
    } catch (_: Exception) { null }
}

@Serializable
data class NotificationItem(
    val id: String,
    val user_id: String,
    val laporan_id: String? = null,
    val jenis: String,
    val judul: String,
    val pesan: String,
    val sudah_dibaca: Boolean,
    val created_at: String,
    val foto_url_hama: String? = null,
    val laporan: LaporanDto? = null
)

@Serializable
data class LaporanUpdateDto(
    val id: String? = null,
    val laporan_id: String,
    val foto_update_url: String,
    val label_ai_update: String? = null,
    val confidence_update: Float? = null,
    val catatan: String? = null,
    val created_at: String = "",
    val user_id: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val gps_accuracy_m: Float? = null,
    val captured_at: String? = null
)

@Serializable
data class LaporanUpdateInsertDto(
    val laporan_id: String,
    val foto_update_url: String,
    val label_ai_update: String,
    val confidence_update: Float,
    val catatan: String,
    val user_id: String,
    val latitude: Double,
    val longitude: Double,
    val gps_accuracy_m: Float,
    val captured_at: String
)

@Serializable
data class LaporanInsertDto(
    val petani_id: String,
    val foto_url: String,
    val label_ai: String?,
    val confidence: Float?,
    val lokasi: String,
    val alamat_lengkap: String,
    val kecamatan_id: String?,
    val deskripsi_gejala: String,
    val jenis_pelaporan: String,
    val prioritas: String,
    val status: String = "menunggu_verifikasi"
)

@Serializable
data class KecamatanDto(
    val id: String,
    val nama_kecamatan: String,
    @SerialName("polygon_geojson") val polygon_geojson: String? = null
)

@Serializable
data class InfoHamaDto(
    val id: String? = null,
    val kategori: String,
    val isi_informasi: String,
    val urutan: Int
)

@Serializable
data class MasterHamaDto(
    val id: String,
    val nama_hama: String,
    val deskripsi: String,
    val ciri_ciri: String,
    val informasi_hama: List<InfoHamaDto> = emptyList()
)

@Serializable
data class MasterPoktanDto(
    val id: String,
    val nama_poktan: String,
    val kecamatan: String,
    val desa: String
)

@Serializable
data class KecamatanSimpleDto(
    val nama_kecamatan: String
)

@Serializable
data class CoordinateParams(
    val p_lat: Double,
    val p_lon: Double
)

@Serializable
data class ProfileNameOnly(val full_name: String? = null)

@Serializable
data class ProfileDirectoryDto(
    val id: String,
    val full_name: String? = null
)

@Serializable
data class PoptWilayahSimple(val popt_id: String? = null)

suspend fun fetchActiveLaporan(): List<LaporanDto> {
    return try {
        supabase.from("vw_hotspot_laporan_aktif")
            .select(columns = Columns.raw(LAPORAN_COLUMNS))
            .decodeList<LaporanDto>()
    } catch (e: Exception) {
        emptyList()
    }
}

suspend fun fetchLaporanUntukPOPT(poptId: String): List<LaporanDto> {
    return try {
        val wilayahList = supabase.from("popt_wilayah")
            .select(columns = Columns.raw("kecamatan_id")) {
                filter { eq("popt_id", poptId) }
            }.decodeList<PoptWilayahDto>()

        val kecIds = wilayahList.map { it.kecamatan_id }
        if (kecIds.isEmpty()) return emptyList()

        supabase.from("laporan")
            .select(columns = Columns.raw(LAPORAN_COLUMNS)) {
                filter { isIn("kecamatan_id", kecIds) }
            }.decodeList<LaporanDto>()
    } catch (e: Exception) {
        emptyList()
    }
}

suspend fun fetchLaporanUntukPeta(): List<LaporanPetaDto> {
    return try {
        supabase.from("vw_laporan_peta")
            .select()
            .decodeList<LaporanPetaDto>()
    } catch (e: Exception) {
        Log.w("LAPORAN_PETA", "Gagal memuat titik peta: ${e.message}")
        emptyList()
    }
}

suspend fun fetchLaporanById(id: String): LaporanDto? {
    return try {
        supabase.from("laporan")
            .select(columns = Columns.raw(LAPORAN_COLUMNS)) {
                filter { eq("id", id) }
            }
            .decodeList<LaporanDto>()
            .firstOrNull()
    } catch (e: Exception) {
        null
    }
}

suspend fun fetchNamaPelapor(petaniId: String): String {
    return try {
        val profile = supabase.from("profile_directory")
            .select(columns = Columns.raw("full_name")) {
                filter { eq("id", petaniId) }
            }
            .decodeSingleOrNull<ProfileNameOnly>()
        profile?.full_name ?: "Petani (Tidak diketahui)"
    } catch (e: Exception) {
        "Petani"
    }
}

suspend fun fetchNamaPoptByKecamatan(kecId: String?): String {
    if (kecId == null) return "Belum Ada Petugas"
    return try {
        val poptWilayah = supabase.from("popt_wilayah")
            .select(Columns.raw("popt_id")) { filter { eq("kecamatan_id", kecId) } }
            .decodeList<PoptWilayahSimple>()
            .firstOrNull()

        val pId = poptWilayah?.popt_id ?: return "Belum Ada Petugas"
        val profile = supabase.from("profile_directory")
            .select(Columns.raw("full_name")) { filter { eq("id", pId) } }
            .decodeSingleOrNull<ProfileNameOnly>()
        profile?.full_name ?: "Petugas POPT"
    } catch (e: Exception) {
        "Petugas POPT"
    }
}

suspend fun getKecamatanIdByCoordinate(lat: Double, lon: Double): String? {
    return try {
        val result = supabase.postgrest.rpc(
            "get_kecamatan_id_by_koordinat",
            CoordinateParams(p_lat = lat, p_lon = lon)
        ).decodeAsOrNull<String>()
        result?.takeIf { it.isNotBlank() && it != "null" }
    } catch (e: Exception) {
        null
    }
}

suspend fun submitReportToSupabase(
    photoBytes: ByteArray,
    results: List<DetectionResult>,
    lat: Double,
    lon: Double,
    alamatLengkap: String,
    userId: String,
    deskripsiGejala: String,
    jenisPelaporan: String = "AI",
    isManualMode: Boolean,
    manualPestName: String
): Result<String> {
    return try {
        val kecId = getKecamatanIdByCoordinate(lat, lon)
        if (kecId == null) throw Exception("OUT_OF_BOUNDS")

        val fileName = "laporan_${System.currentTimeMillis()}.jpg"
        val bucket = supabase.storage.from("evidence_photos")
        bucket.upload(fileName, photoBytes)
        val publicUrl = bucket.publicUrl(fileName)

        val bestResult = results.maxByOrNull { it.score }
        val locationString = "SRID=4326;POINT($lon $lat)"

        val finalLabel = if (isManualMode) {
            if (manualPestName == "Tidak Tahu" || manualPestName.isBlank()) null else manualPestName
        } else {
            bestResult?.label
        }

        val finalConfidence = if (isManualMode) null else bestResult?.score
        val finalTipe = if (isManualMode) "MANUAL" else "AI"
        val finalPrioritas = if (isManualMode) "rendah"
        else if (finalConfidence != null && finalConfidence > 0.5f) "tinggi" else "sedang"

        val laporan = LaporanInsertDto(
            petani_id = userId,
            foto_url = publicUrl,
            label_ai = finalLabel,
            confidence = finalConfidence,
            lokasi = locationString,
            alamat_lengkap = alamatLengkap,
            kecamatan_id = kecId,
            deskripsi_gejala = deskripsiGejala,
            jenis_pelaporan = finalTipe,
            prioritas = finalPrioritas,
            status = "menunggu_verifikasi"
        )

        supabase.from("laporan").insert(laporan)
        Result.success("Berhasil")
    } catch (e: Exception) {
        Result.failure(e)
    }
}

suspend fun fetchLaporanUpdates(laporanId: String): List<LaporanUpdateDto> {
    return try {
        supabase.from("laporan_updates")
            .select {
                filter { eq("laporan_id", laporanId) }
                order("created_at", Order.ASCENDING)
            }
            .decodeList<LaporanUpdateDto>()
    } catch (e: Exception) {
        emptyList()
    }
}

suspend fun submitLaporanUpdate(
    laporanId: String,
    userId: String,
    photoBytes: ByteArray,
    labelAi: String,
    confidence: Float,
    catatan: String,
    latitude: Double,
    longitude: Double,
    gpsAccuracyMeters: Float,
    capturedAt: String
): Result<Unit> {
    return try {
        val fileName = "update_${laporanId}_${System.currentTimeMillis()}.jpg"
        val bucket = supabase.storage.from("evidence_photos")
        bucket.upload(fileName, photoBytes)
        val publicUrl = bucket.publicUrl(fileName)

        val updateData = LaporanUpdateInsertDto(
            laporan_id = laporanId,
            foto_update_url = publicUrl,
            label_ai_update = labelAi,
            confidence_update = confidence,
            catatan = catatan,
            user_id = userId,
            latitude = latitude,
            longitude = longitude,
            gps_accuracy_m = gpsAccuracyMeters,
            captured_at = capturedAt
        )

        supabase.from("laporan_updates").insert(updateData)
        Result.success(Unit)
    } catch (e: Exception) {
        Result.failure(e)
    }
}

@Serializable
data class PerluKunjunganParams(
    val p_laporan_id: String,
    val p_alasan: String,
    val p_waktu_kunjungan: String,
    val p_catatan_jadwal: String? = null,
    val p_instruksi: String? = null,
    val p_radius: Double? = null,
    val p_corrected_label: String? = null
)

suspend fun setLaporanPerluKunjungan(
    laporanId: String,
    alasan: String,
    waktuKunjungan: String,
    catatanJadwal: String?,
    instruksi: String?,
    radius: Double?,
    correctedLabel: String?
): Result<Unit> = try {
    require(alasan.trim().length >= 5) { "Alasan kunjungan wajib diisi minimal 5 karakter." }
    require(waktuKunjungan.isNotBlank()) { "Tanggal dan jam kunjungan wajib dipilih." }
    supabase.postgrest.rpc(
        "set_laporan_perlu_kunjungan",
        PerluKunjunganParams(
            p_laporan_id = laporanId,
            p_alasan = alasan.trim(),
            p_waktu_kunjungan = waktuKunjungan,
            p_catatan_jadwal = catatanJadwal?.trim()?.takeIf { it.isNotEmpty() },
            p_instruksi = instruksi?.trim()?.takeIf { it.isNotEmpty() },
            p_radius = radius,
            p_corrected_label = correctedLabel?.trim()?.takeIf { it.isNotEmpty() }
        )
    )
    Result.success(Unit)
} catch (e: Exception) {
    Result.failure(e)
}

// Aturan transisi status yang otoritatif tetap ditegakkan oleh trigger/RLS di database.
suspend fun updateLaporanStatus(
    laporanId: String,
    status: String,
    instruksi: String? = null,
    radius: Double? = null,
    correctedLabel: String? = null,
    alasanPenolakan: String? = null,
    alasanKunjungan: String? = null
): Result<Unit> {
    return try {
        val statusDiizinkan = setOf(
            "menunggu_verifikasi",
            "penanganan_mandiri",
            "perlu_kunjungan",
            "selesai",
            "ditolak"
        )
        require(status in statusDiizinkan) { "Status laporan tidak dikenal." }

        if (status == "ditolak") {
            require(!alasanPenolakan.isNullOrBlank() && alasanPenolakan.trim().length >= 5) {
                "Alasan penolakan wajib diisi minimal 5 karakter."
            }
        }

        supabase.from("laporan").update({
            set("status", status)
            if (instruksi != null) set("instruksi_popt", instruksi)
            if (radius != null) set("radius", radius)
            if (correctedLabel != null) set("label_ai", correctedLabel)
            if (status == "ditolak") set("alasan_penolakan", alasanPenolakan!!.trim())
            if (status == "perlu_kunjungan" && !alasanKunjungan.isNullOrBlank()) {
                set("alasan_kunjungan", alasanKunjungan.trim())
            }
        }) {
            filter { eq("id", laporanId) }
        }
        Result.success(Unit)
    } catch (e: Exception) {
        Result.failure(e)
    }
}

suspend fun rejectLaporan(laporanId: String, alasanPenolakan: String): Result<Unit> {
    return updateLaporanStatus(
        laporanId = laporanId,
        status = "ditolak",
        alasanPenolakan = alasanPenolakan
    )
}

suspend fun markLaporanSelesai(laporanId: String): Result<Unit> {
    return updateLaporanStatus(laporanId = laporanId, status = "selesai")
}

suspend fun fetchMasterPoktan(): List<MasterPoktanDto> {
    return try {
        supabase.from("master_poktan").select().decodeList<MasterPoktanDto>()
    } catch (e: Exception) {
        emptyList()
    }
}

@Serializable
data class LocationValidationDto(
    @SerialName("is_in_sawah") val isInSawah: Boolean,
    @SerialName("kecamatan_id") val kecId: String?,
    @SerialName("nama_kecamatan") val kecName: String?
)

suspend fun fetchSemuaKecamatan(): List<KecamatanDto> {
    // Baca view GeoJSON, bukan tabel kecamatan langsung.
    // Biarkan exception diteruskan agar ViewModel dapat menampilkan error yang nyata.
    return supabase.from("vw_kecamatan_geojson")
        .select(columns = Columns.raw("id, nama_kecamatan, polygon_geojson"))
        .decodeList<KecamatanDto>()
}

fun parseGeoJsonToLatLng(geoJsonString: String?): List<List<LatLng>> {
    if (geoJsonString.isNullOrBlank()) return emptyList()
    val polygons = mutableListOf<List<LatLng>>()
    try {
        val geoJson = Json.parseToJsonElement(geoJsonString).jsonObject
        val type = geoJson["type"]?.jsonPrimitive?.content
        val coordinates = geoJson["coordinates"]?.jsonArray ?: return emptyList()

        when (type) {
            "MultiPolygon" -> {
                for (multiPolygonElement in coordinates) {
                    val polygonArray = multiPolygonElement.jsonArray
                    if (polygonArray.isNotEmpty()) {
                        val outerRing = polygonArray[0].jsonArray
                        val latLngs = outerRing.mapNotNull { coord ->
                            val pt = coord.jsonArray
                            if (pt.size >= 2) LatLng(pt[1].jsonPrimitive.double, pt[0].jsonPrimitive.double) else null
                        }
                        if (latLngs.size >= 3) polygons.add(latLngs)
                    }
                }
            }
            "Polygon" -> {
                if (coordinates.isNotEmpty()) {
                    val outerRing = coordinates[0].jsonArray
                    val latLngs = outerRing.mapNotNull { coord ->
                        val pt = coord.jsonArray
                        if (pt.size >= 2) LatLng(pt[1].jsonPrimitive.double, pt[0].jsonPrimitive.double) else null
                    }
                    if (latLngs.size >= 3) polygons.add(latLngs)
                }
            }
        }
    } catch (e: Exception) {
        Log.w("KECAMATAN_GEOJSON", "Gagal parsing GeoJSON kecamatan: ${e.message}")
    }
    return polygons
}

suspend fun fetchMasterHama(): List<MasterHamaDto> {
    return try {
        supabase.from("master_hama")
            .select(columns = Columns.raw("*, informasi_hama(*)"))
            .decodeList<MasterHamaDto>()
    } catch (e: Exception) {
        emptyList()
    }
}

@Serializable
data class LaporanStatusRiwayatDto(
    val id: String,
    val laporan_id: String,
    val status_sebelumnya: String? = null,
    val status_baru: String,
    val jenis_peristiwa: String,
    val catatan: String? = null,
    val instruksi_popt: String? = null,
    val alasan_kunjungan: String? = null,
    val alasan_penolakan: String? = null,
    val label_ai: String? = null,
    val confidence: Double? = null,
    val foto_url: String? = null,
    val deskripsi_gejala: String? = null,
    val alamat_lengkap: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val actor_id: String? = null,
    val created_at: String = ""
)

data class LaporanTimelineEventDto(
    val history: LaporanStatusRiwayatDto,
    val actorName: String?
)

suspend fun fetchLaporanStatusRiwayat(laporanId: String): List<LaporanTimelineEventDto> = try {
    val history = supabase.from("laporan_status_riwayat").select {
        filter { eq("laporan_id", laporanId) }
        order("created_at", Order.ASCENDING)
    }.decodeList<LaporanStatusRiwayatDto>()

    val actorIds = history.mapNotNull { it.actor_id }.distinct()
    val actorNames = if (actorIds.isEmpty()) {
        emptyMap()
    } else {
        supabase.from("profile_directory")
            .select(columns = Columns.raw("id, full_name")) {
                filter { isIn("id", actorIds) }
            }
            .decodeList<ProfileDirectoryDto>()
            .associate { it.id to it.full_name }
    }

    history.map { event ->
        LaporanTimelineEventDto(event, event.actor_id?.let { actorNames[it] })
    }
} catch (e: Exception) {
    Log.w("LAPORAN_TIMELINE", "Gagal memuat riwayat: ${e.message}")
    emptyList()
}

@Serializable
data class JadwalKunjunganDto(
    val id: String = "",
    val laporan_id: String,
    val popt_id: String,
    val waktu_kunjungan: String,
    val catatan: String? = null,
    val status: String = "menunggu_konfirmasi",
    val usulan_waktu: String? = null,
    val alasan_reschedule: String? = null,
    val catatan_hasil: String? = null,
    val evidence_foto_url: String? = null,
    val checkin_latitude: Double? = null,
    val checkin_longitude: Double? = null,
    val checkin_accuracy_m: Double? = null,
    val checkin_at: String? = null,
    val dibuat_pada: String = "",
    val diperbarui_pada: String = ""
)

@Serializable
data class JadwalKunjunganInsertDto(
    val laporan_id: String,
    val popt_id: String,
    val waktu_kunjungan: String,
    val catatan: String? = null,
    val status: String = "menunggu_konfirmasi"
)

suspend fun buatJadwalKunjungan(
    laporanId: String,
    poptId: String,
    waktuKunjungan: String,
    catatan: String?
): Result<Unit> = try {
    supabase.postgrest.rpc("buat_jadwal_kunjungan", buildJsonObject {
        put("p_laporan_id", laporanId)
        put("p_waktu_kunjungan", waktuKunjungan)
        put("p_catatan", catatan?.trim()?.takeIf { it.isNotEmpty() })
    })
    Result.success(Unit)
} catch (e: Exception) { Result.failure(e) }

suspend fun fetchJadwalKunjungan(laporanId: String): List<JadwalKunjunganDto> = try {
    supabase.from("jadwal_kunjungan").select {
        filter { eq("laporan_id", laporanId) }
        order("waktu_kunjungan", Order.DESCENDING)
    }.decodeList<JadwalKunjunganDto>()
} catch (_: Exception) { emptyList() }

suspend fun updateCatatanKunjungan(jadwalId: String, catatan: String): Result<Unit> = try {
    supabase.postgrest.rpc("update_catatan_kunjungan", buildJsonObject {
        put("p_jadwal_id", jadwalId)
        put("p_catatan", catatan.trim())
    })
    Result.success(Unit)
} catch (e: Exception) {
    Result.failure(e)
}

suspend fun konfirmasiJadwalKunjungan(jadwalId: String): Result<Unit> = try {
    supabase.postgrest.rpc("konfirmasi_jadwal_kunjungan", buildJsonObject { put("p_jadwal_id", jadwalId) })
    Result.success(Unit)
} catch (e: Exception) { Result.failure(e) }

suspend fun usulkanJadwalUlang(jadwalId: String, waktuBaru: String, alasan: String): Result<Unit> = try {
    require(alasan.trim().length >= 5) { "Alasan perubahan jadwal minimal 5 karakter." }
    supabase.postgrest.rpc("usulkan_jadwal_ulang", buildJsonObject {
        put("p_jadwal_id", jadwalId)
        put("p_waktu_baru", waktuBaru)
        put("p_alasan", alasan.trim())
    })
    Result.success(Unit)
} catch (e: Exception) { Result.failure(e) }

suspend fun terimaUsulanJadwalUlang(jadwalId: String): Result<Unit> = try {
    supabase.postgrest.rpc("terima_usulan_jadwal_ulang", buildJsonObject { put("p_jadwal_id", jadwalId) })
    Result.success(Unit)
} catch (e: Exception) { Result.failure(e) }

suspend fun tolakUsulanJadwalUlang(jadwalId: String): Result<Unit> = try {
    supabase.postgrest.rpc("tolak_usulan_jadwal_ulang", buildJsonObject { put("p_jadwal_id", jadwalId) })
    Result.success(Unit)
} catch (e: Exception) { Result.failure(e) }

suspend fun ubahJadwalKunjungan(jadwalId: String, waktuBaru: String, catatan: String?): Result<Unit> = try {
    supabase.postgrest.rpc("ubah_jadwal_kunjungan", buildJsonObject {
        put("p_jadwal_id", jadwalId)
        put("p_waktu_baru", waktuBaru)
        put("p_catatan", catatan?.trim()?.takeIf { it.isNotEmpty() })
    })
    Result.success(Unit)
} catch (e: Exception) { Result.failure(e) }

suspend fun tandaiKunjunganTerlaksana(
    jadwalId: String,
    catatanHasil: String,
    evidenceFotoUrl: String,
    latitude: Double,
    longitude: Double,
    accuracyMeters: Double
): Result<Unit> = try {
    require(catatanHasil.trim().length >= 5) { "Catatan hasil kunjungan minimal 5 karakter." }
    require(evidenceFotoUrl.isNotBlank()) { "Foto hasil kunjungan wajib diunggah." }
    supabase.postgrest.rpc("selesaikan_kunjungan", buildJsonObject {
        put("p_jadwal_id", jadwalId)
        put("p_catatan_hasil", catatanHasil.trim())
        put("p_evidence_foto_url", evidenceFotoUrl)
        put("p_latitude", latitude)
        put("p_longitude", longitude)
        put("p_accuracy_m", accuracyMeters)
    })
    Result.success(Unit)
} catch (e: Exception) { Result.failure(e) }

suspend fun uploadVisitEvidence(photoBytes: ByteArray, jadwalId: String): Result<String> = try {
    val fileName = "visit_${jadwalId}_${System.currentTimeMillis()}.jpg"
    val bucket = supabase.storage.from("evidence_photos")
    bucket.upload(fileName, photoBytes)
    Result.success(bucket.publicUrl(fileName))
} catch (e: Exception) { Result.failure(e) }
