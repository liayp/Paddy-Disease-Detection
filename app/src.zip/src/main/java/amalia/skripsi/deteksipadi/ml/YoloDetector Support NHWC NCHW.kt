package amalia.skripsi.deteksipadi.ml

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import android.util.Log
import androidx.core.graphics.scale
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

data class DetectionResult_backup(
    val box: RectF,
    val score: Float,
    val label: String,
    val labelIndex: Int
)

class YoloDetectorSupportNHWCdanNCHW(
    context: Context,
    modelName: String = "best.tflite",
    private val confThreshold: Float = 0.40f,
    private val iouThreshold: Float = 0.45f
) {
    companion object {
        private const val TAG = "YoloDetector"
        private const val INPUT_SIZE = 640
        private const val NUM_CLASSES = 4
        private const val NUM_FEATURES = 4 + NUM_CLASSES

        private val LABELS = listOf(
            "Blast",
            "Hama Putih Palsu",
            "Hawar Daun Bakteri",
            "Stem Borer"
        )
    }

    private var interpreter: Interpreter? = null

    private var inputShape = intArrayOf()
    private var inputType = DataType.FLOAT32
    private var channelsFirst = false

    @Volatile
    private var isClosed = false

    private val labels = LABELS

    init {
        try {
            val model = FileUtil.loadMappedFile(context, modelName)

            val options = Interpreter.Options().apply {
                setNumThreads(4)
            }

            interpreter = Interpreter(model, options)

            val inputTensor = interpreter!!.getInputTensor(0)

            inputShape = inputTensor.shape()
            inputType = inputTensor.dataType()

            channelsFirst = when {
                inputShape.contentEquals(intArrayOf(1, 3, INPUT_SIZE, INPUT_SIZE)) -> true
                inputShape.contentEquals(intArrayOf(1, INPUT_SIZE, INPUT_SIZE, 3)) -> false
                else -> error(
                    "Input shape tidak didukung: ${inputShape.contentToString()}"
                )
            }

            Log.i(TAG, "Model loaded successfully")
            Log.i(TAG, "Input type: $inputType")
            Log.i(TAG, "Input shape: ${inputShape.contentToString()}")
            Log.i(TAG, "Input layout: ${if (channelsFirst) "NCHW" else "NHWC"}")
        } catch (e: Exception) {
            Log.e(TAG, "Error loading model", e)
        }
    }

    fun detect(bitmap: Bitmap): List<DetectionResult> {
        synchronized(this) {
            if (isClosed || interpreter == null) return emptyList()
        }

        return try {
            val resized = bitmap.scale(INPUT_SIZE, INPUT_SIZE)
            val input = bitmapToByteBuffer(resized)

            val outputTensor = interpreter!!.getOutputTensor(0)
            val outputShape = outputTensor.shape()

            val output = when {
                outputShape.contentEquals(intArrayOf(1, NUM_FEATURES, 8400)) -> {
                    Array(1) { Array(NUM_FEATURES) { FloatArray(8400) } }
                }

                outputShape.contentEquals(intArrayOf(1, 8400, NUM_FEATURES)) -> {
                    Array(1) { Array(8400) { FloatArray(NUM_FEATURES) } }
                }

                else -> {
                    error(
                        "Output shape tidak didukung: ${outputShape.contentToString()}"
                    )
                }
            }

            synchronized(this) {
                if (isClosed || interpreter == null) return emptyList()
                interpreter?.run(input, output)
            }

            val results = parseOutput(output, outputShape)

            applyNMS(results)
        } catch (e: Exception) {
            Log.e(TAG, "Error detect", e)
            emptyList()
        }
    }

    private fun bitmapToByteBuffer(bitmap: Bitmap): ByteBuffer {
        val inputTensor = interpreter!!.getInputTensor(0)

        val buffer = ByteBuffer
            .allocateDirect(inputTensor.numBytes())
            .order(ByteOrder.nativeOrder())

        val pixels = IntArray(INPUT_SIZE * INPUT_SIZE)

        bitmap.getPixels(
            pixels,
            0,
            INPUT_SIZE,
            0,
            0,
            INPUT_SIZE,
            INPUT_SIZE
        )

        if (channelsFirst) {
            val red = FloatArray(pixels.size)
            val green = FloatArray(pixels.size)
            val blue = FloatArray(pixels.size)

            for (i in pixels.indices) {
                val pixel = pixels[i]
                red[i] = ((pixel shr 16) and 0xFF) / 255f
                green[i] = ((pixel shr 8) and 0xFF) / 255f
                blue[i] = (pixel and 0xFF) / 255f
            }

            for (value in red) buffer.putFloat(value)
            for (value in green) buffer.putFloat(value)
            for (value in blue) buffer.putFloat(value)
        } else {
            for (pixel in pixels) {
                buffer.putFloat(((pixel shr 16) and 0xFF) / 255f)
                buffer.putFloat(((pixel shr 8) and 0xFF) / 255f)
                buffer.putFloat((pixel and 0xFF) / 255f)
            }
        }

        buffer.rewind()
        return buffer
    }

    private fun parseOutput(
        output: Any,
        outputShape: IntArray
    ): List<DetectionResult> {
        val detections = ArrayList<DetectionResult>()

        val channelsFirstOutput = outputShape[1] == NUM_FEATURES

        val anchors = if (channelsFirstOutput) {
            outputShape[2]
        } else {
            outputShape[1]
        }

        for (i in 0 until anchors) {
            var maxScore = 0f
            var bestClassIdx = -1

            for (c in 0 until NUM_CLASSES) {
                val score = if (channelsFirstOutput) {
                    @Suppress("UNCHECKED_CAST")
                    (output as Array<Array<FloatArray>>)[0][4 + c][i]
                } else {
                    @Suppress("UNCHECKED_CAST")
                    (output as Array<Array<FloatArray>>)[0][i][4 + c]
                }

                if (score > maxScore) {
                    maxScore = score
                    bestClassIdx = c
                }
            }

            if (maxScore < confThreshold) continue

            val cx = getOutputValue(output, outputShape, 0, i)
            val cy = getOutputValue(output, outputShape, 1, i)
            val w = getOutputValue(output, outputShape, 2, i)
            val h = getOutputValue(output, outputShape, 3, i)

            val left = (cx - w / 2).coerceIn(0f, 1f)
            val top = (cy - h / 2).coerceIn(0f, 1f)
            val right = (cx + w / 2).coerceIn(0f, 1f)
            val bottom = (cy + h / 2).coerceIn(0f, 1f)

            detections.add(
                DetectionResult(
                    box = RectF(left, top, right, bottom),
                    score = maxScore,
                    label = labels.getOrElse(bestClassIdx) { "Unknown" },
                    labelIndex = bestClassIdx
                )
            )
        }

        return detections
    }

    private fun getOutputValue(
        output: Any,
        outputShape: IntArray,
        featureIndex: Int,
        anchorIndex: Int
    ): Float {
        return if (outputShape[1] == NUM_FEATURES) {
            @Suppress("UNCHECKED_CAST")
            (output as Array<Array<FloatArray>>)[0][featureIndex][anchorIndex]
        } else {
            @Suppress("UNCHECKED_CAST")
            (output as Array<Array<FloatArray>>)[0][anchorIndex][featureIndex]
        }
    }

    private fun applyNMS(
        list: List<DetectionResult>
    ): List<DetectionResult> {
        if (list.isEmpty()) return emptyList()

        val sorted = list
            .sortedByDescending { it.score }
            .toMutableList()

        val nmsList = ArrayList<DetectionResult>()

        while (sorted.isNotEmpty()) {
            val best = sorted.removeAt(0)
            nmsList.add(best)

            val iterator = sorted.iterator()

            while (iterator.hasNext()) {
                val other = iterator.next()

                if (calculateIoU(best.box, other.box) > iouThreshold) {
                    iterator.remove()
                }
            }
        }

        return nmsList
    }

    private fun calculateIoU(
        a: RectF,
        b: RectF
    ): Float {
        val areaA =
            (a.right - a.left) *
                    (a.bottom - a.top)

        val areaB =
            (b.right - b.left) *
                    (b.bottom - b.top)

        val intersectionLeft =
            max(a.left, b.left)

        val intersectionTop =
            max(a.top, b.top)

        val intersectionRight =
            min(a.right, b.right)

        val intersectionBottom =
            min(a.bottom, b.bottom)

        val intersectionArea =
            max(
                0f,
                intersectionRight - intersectionLeft
            ) *
                    max(
                        0f,
                        intersectionBottom - intersectionTop
                    )

        val unionArea =
            areaA + areaB - intersectionArea

        return if (unionArea <= 0f) {
            0f
        } else {
            intersectionArea / unionArea
        }
    }

    fun close() {
        synchronized(this) {
            if (!isClosed) {
                isClosed = true
                interpreter?.close()
                interpreter = null
            }
        }
    }
}