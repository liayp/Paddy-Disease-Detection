package amalia.skripsi.deteksipadi.util

import amalia.skripsi.deteksipadi.services.HazardDetectionService
import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.core.content.edit

private const val PREFS_NAME = "permission_prefs"
private const val KEY_NOTIFICATION_PERMISSION_PROMPTED =
    "notification_permission_prompted"

@Composable
fun RequestPermissionsAndStartService() {
    val context = LocalContext.current

    val prefs = remember {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun startHazardService() {
        val intent = Intent(context, HazardDetectionService::class.java)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    val locationPermissionLauncher =
        rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->

            val locationGranted =
                permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                        permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true

            if (locationGranted) {
                startHazardService()
            }
        }

    fun requestLocationPermission() {
        val hasFineLocation =
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

        val hasCoarseLocation =
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED

        if (hasFineLocation || hasCoarseLocation) {
            startHazardService()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    val notificationPermissionLauncher =
        rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) {
            // Yang penting: prompt awal hanya dianggap sudah diproses
            // setelah sistem mengembalikan hasil permission.
            prefs.edit {
                putBoolean(KEY_NOTIFICATION_PERMISSION_PROMPTED, true)
            }

            // Setelah dialog notifikasi selesai, lanjut ke lokasi.
            requestLocationPermission()
        }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            val notificationGranted =
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED

            val alreadyPrompted =
                prefs.getBoolean(
                    KEY_NOTIFICATION_PERMISSION_PROMPTED,
                    false
                )

            when {
                notificationGranted -> {
                    prefs.edit {
                        putBoolean(
                            KEY_NOTIFICATION_PERMISSION_PROMPTED,
                            true
                        )
                    }

                    requestLocationPermission()
                }

                !alreadyPrompted -> {
                    notificationPermissionLauncher.launch(
                        Manifest.permission.POST_NOTIFICATIONS
                    )
                }

                else -> {
                    // Sudah pernah ditanya sebelumnya.
                    // Jangan tampilkan dialog lagi setiap launch.
                    requestLocationPermission()
                }
            }

        } else {
            // Android < 13 tidak memiliki runtime notification permission.
            requestLocationPermission()
        }
    }
}