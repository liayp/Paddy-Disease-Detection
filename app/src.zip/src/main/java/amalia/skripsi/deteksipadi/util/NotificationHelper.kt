package amalia.skripsi.deteksipadi.util

import amalia.skripsi.deteksipadi.R
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlin.random.Random
import androidx.core.content.edit

object NotificationHelper {
    const val CHANNEL_URGENT = "channel_alert_urgent"
    const val CHANNEL_NORMAL = "channel_service_running"
    private const val PREFS = "notification_settings"
    private const val KEY_ENABLED = "push_notifications_enabled"

    fun areNotificationsEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, true)

    fun setNotificationsEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit {
            putBoolean(KEY_ENABLED, enabled)
        }
    }

    @SuppressLint("FullScreenIntentPolicy")
    fun buildNotification(
        context: Context, title: String, message: String, channelId: String, channelName: String,
        intent: PendingIntent? = null, isUrgent: Boolean = false, isOngoing: Boolean = false
    ): Notification {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val importance = if (isOngoing) NotificationManager.IMPORTANCE_LOW else NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(channelId, channelName, importance).apply {
                description = "Notifikasi Deteksi Padi"
                enableVibration(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setShowBadge(true)
            }
            notificationManager.createNotificationChannel(channel)
        }
        val largeIconBitmap = BitmapFactory.decodeResource(context.resources, R.mipmap.ic_launcher)
        val colorInt = if (isUrgent) Color.RED else ContextCompat.getColor(context, R.color.primary)
        return NotificationCompat.Builder(context, channelId)
            .setPriority(if (isUrgent) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .setSmallIcon(R.drawable.ic_stat_padi)
            .setFullScreenIntent(intent, isUrgent)
            .setGroup("laporan_padi_group")
            .setLargeIcon(largeIconBitmap)
            .setColor(colorInt)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setOngoing(isOngoing)
            .setAutoCancel(!isOngoing)
            .apply { if (intent != null) setContentIntent(intent) }
            .build()
    }

    fun showNotification(
        context: Context,
        title: String,
        message: String,
        channelId: String,
        channelName: String,
        intent: PendingIntent? = null,
        isUrgent: Boolean = false
    ) {
        if (!areNotificationsEnabled(context)) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(Random.nextInt(), buildNotification(context, title, message, channelId, channelName, intent, isUrgent))
    }
}
